==========================================
    MysticSticks 리소스팩 예제
    체력바 위 커스텀 마나 UI
==========================================

【개요】
이 리소스팩은 Negative Space Font 기술을 사용하여
보스바를 체력바 위에 표시하는 예제입니다.

==========================================
【폴더 구조】
==========================================

example_resourcepack/
├── pack.mcmeta                    # 팩 정보
├── pack.png                        # 팩 아이콘 (선택)
└── assets/
    └── minecraft/
        ├── font/
        │   └── default.json        # 폰트 설정
        └── textures/
            ├── font/               # 마나바 이미지들
            │   ├── mana_bar_bg.png
            │   ├── mana_bar_full.png
            │   ├── mana_bar_empty.png
            │   ├── mana_bar_half.png
            │   ├── mana_icon.png
            │   └── mana_glow.png
            └── gui/
                └── bars.png        # 투명 보스바

==========================================
【설치 방법】
==========================================

1. 이미지 파일 생성:
   - IMAGE_GUIDE.txt 참조
   - 각 이미지를 제작하여 font 폴더에 저장

2. bars.png 수정:
   - 바닐라 bars.png 복사
   - 보스바 영역 투명화

3. 리소스팩 압축:
   - example_resourcepack 폴더 전체를 ZIP으로 압축
   - 파일명: MysticSticks_UI.zip

4. 서버 설정:
   server.properties:
   resource-pack=직접링크URL
   resource-pack-sha1=SHA1해시값

5. 플러그인 설정:
   config.yml:
   mana:
     display-type: "bossbar"
     use-resource-pack: true
     use-negative-space: true

==========================================
【테스트 명령어】
==========================================

1. 리소스팩 적용 확인:
   F3+T (리소스팩 리로드)

2. 마나바 표시:
   /ms mana display bossbar

3. 마나 테스트:
   /ms give lightning_stick
   막대기 사용하여 마나 소모

4. 위치 확인:
   체력바 위에 마나바가 표시되는지 확인

==========================================
【커스터마이징】
==========================================

ascent 값 조정 (default.json):
• -60: 더 위로 올리기
• -70: 더 아래로 내리기
• -64: 기본값 (체력바 바로 위)

색상 변경:
• 이미지 파일 직접 수정
• 다양한 색상 팔레트 적용

애니메이션:
• 여러 프레임 이미지 추가
• 코드에서 시간별 문자 변경

==========================================
【문제 해결】
==========================================

Q: 마나바가 안 보여요
A: 
- 리소스팩 적용 확인 (F3+T)
- config.yml 설정 확인
- 보스바 표시 모드 확인

Q: 위치가 이상해요
A: 
- GUI Scale 설정 확인
- ascent 값 조정
- 해상도별 테스트

Q: 이미지가 깨져요
A: 
- 이미지 크기 확인
- PNG 포맷 확인
- 알파 채널 확인

==========================================
【호스팅 서비스】
==========================================

무료 호스팅:
1. GitHub Pages
2. Dropbox (직접 링크)
3. Google Drive (공유 링크)
4. MediaFire

유료 호스팅:
1. 자체 웹서버
2. CDN 서비스
3. 마인크래프트 전용 호스팅

==========================================
【추가 자료】
==========================================

• Negative Space Font:
  https://github.com/AmberWat/NegativeSpaceFont

• 마인크래프트 위키 (Custom Font):
  https://minecraft.wiki/w/Resource_pack

• 폰트 생성 도구:
  https://minecraft.tools/en/custom-font.php

==========================================
제작: Claude AI Assistant
버전: 1.2
==========================================
